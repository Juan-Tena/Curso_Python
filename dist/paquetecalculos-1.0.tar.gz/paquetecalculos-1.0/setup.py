from setuptools import setup

setup(

	name="paquetecalculos", 
	version="1.0",
	descption="Paquete de redondeo y potencia",
	author="Juan Tena",
	author_email="jbtena@gmil.com",
	url="www.linkedin.com/in/juantenaestelles",
	packages=["calculos","calculos.redondeo_potencia"]



	)