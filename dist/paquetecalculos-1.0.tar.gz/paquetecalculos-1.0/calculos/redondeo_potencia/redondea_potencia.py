
def potencia(base,exponente):
	print("El resultado de elevar ", base, " a ", exponente," es: ", base**exponente)

def redondear(numero):
	print("El resultado del redondeo es: ", round(numero))