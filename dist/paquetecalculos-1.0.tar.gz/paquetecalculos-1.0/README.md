![myimage-alt-tag](https://github.com/Juan-Tena/Curso_Python/blob/master/Imagenes/python-logo.png) 

 Ejemplos creados en el curso de Python
